# email_utils.py
# Basic structure
