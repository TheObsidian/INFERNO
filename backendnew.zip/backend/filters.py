# filters.py
# Basic structure
