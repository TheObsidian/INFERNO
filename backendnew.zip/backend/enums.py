# enums.py
# Basic structure
