# constants.py
# Basic structure
