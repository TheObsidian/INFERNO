
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from . import crud, models, schemas
from .database import get_db

router = APIRouter()

@router.post("/users/", response_model=schemas.User)
def create_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
    return crud.create_user(db, user=user)

@router.get("/users/", response_model=List[schemas.User])
def read_users(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    users = crud.get_users(db, skip=skip, limit=limit)
    return users

@router.post("/tickets/", response_model=schemas.Ticket)
def create_ticket(ticket: schemas.TicketCreate, db: Session = Depends(get_db)):
    return crud.create_ticket(db, ticket=ticket)

@router.get("/tickets/", response_model=List[schemas.Ticket])
def read_tickets(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    tickets = crud.get_tickets(db, skip=skip, limit=limit)
    return tickets

# ... (Similar controller operations for EventSchedule, Feedback, EventAttendee, FAQ, EventAnnouncement, SocialLink, Waitlist, Merchandise, MerchandiseOrder, EventReport)

@router.post("/event_schedules/", response_model=schemas.EventSchedule)
def create_event_schedule(event_schedule: schemas.EventScheduleCreate, db: Session = Depends(get_db)):
    return crud.create_event_schedule(db, event_schedule=event_schedule)

@router.get("/event_schedules/", response_model=List[schemas.EventSchedule])
def read_event_schedules(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    return crud.get_event_schedules(db, skip=skip, limit=limit)

@router.post("/feedbacks/", response_model=schemas.Feedback)
def create_feedback(feedback: schemas.FeedbackCreate, db: Session = Depends(get_db)):
    return crud.create_feedback(db, feedback=feedback)

@router.get("/feedbacks/", response_model=List[schemas.Feedback])
def read_feedbacks(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    return crud.get_feedbacks(db, skip=skip, limit=limit)

# ... (And so on for the rest of the new models: EventAttendee, FAQ, EventAnnouncement, SocialLink, Waitlist, Merchandise, MerchandiseOrder, EventReport)

@router.post("/event_attendees/", response_model=schemas.EventAttendee)
def create_event_attendee(event_attendee: schemas.EventAttendeeCreate, db: Session = Depends(get_db)):
    return crud.create_event_attendee(db, event_attendee=event_attendee)

@router.get("/event_attendees/", response_model=List[schemas.EventAttendee])
def read_event_attendees(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    return crud.get_event_attendees(db, skip=skip, limit=limit)

# ... (And so on for the rest of the new models)

# Routes for Category

@router.post("/categories/", response_model=schemas.Category)
def create_category(category: schemas.CategoryCreate, db: Session = Depends(get_db)):
    return crud.create_category(db, category=category)

@router.get("/categories/", response_model=List[schemas.Category])
def get_categories(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    return crud.get_categories(db, skip=skip, limit=limit)

@router.get("/categories/{category_id}", response_model=schemas.Category)
def get_category(category_id: int, db: Session = Depends(get_db)):
    db_category = crud.get_category(db, category_id=category_id)
    if db_category is None:
        raise HTTPException(status_code=404, detail="Category not found")
    return db_category

@router.put("/categories/{category_id}", response_model=schemas.Category)
def update_category(category_id: int, category: schemas.CategoryCreate, db: Session = Depends(get_db)):
    db_category = crud.get_category(db, category_id=category_id)
    if db_category is None:
        raise HTTPException(status_code=404, detail="Category not found")
    return crud.update_category(db, db_category=db_category, category=category)

@router.delete("/categories/{category_id}", response_model=schemas.Category)
def delete_category(category_id: int, db: Session = Depends(get_db)):
    db_category = crud.get_category(db, category_id=category_id)
    if db_category is None:
        raise HTTPException(status_code=404, detail="Category not found")
    crud.delete_category(db, db_category=db_category)
    return db_category

# Routes for Feedback

@router.post("/feedbacks/", response_model=schemas.Feedback)
def create_feedback(feedback: schemas.FeedbackCreate, db: Session = Depends(get_db)):
    return crud.create_feedback(db, feedback=feedback)

@router.get("/feedbacks/", response_model=List[schemas.Feedback])
def get_feedbacks(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    return crud.get_feedbacks(db, skip=skip, limit=limit)

# Routes for EventAttendee

@router.post("/event_attendees/", response_model=schemas.EventAttendee)
def create_event_attendee(event_attendee: schemas.EventAttendeeCreate, db: Session = Depends(get_db)):
    return crud.create_event_attendee(db, event_attendee=event_attendee)

@router.get("/event_attendees/", response_model=List[schemas.EventAttendee])
def get_event_attendees(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    return crud.get_event_attendees(db, skip=skip, limit=limit)

# ... (And so on for FAQ, EventAnnouncement, SocialLink, Waitlist, Merchandise, MerchandiseOrder, EventReport)

# Routes for FAQ

@router.post("/faqs/", response_model=schemas.FAQ)
def create_faq(faq: schemas.FAQCreate, db: Session = Depends(get_db)):
    return crud.create_faq(db, faq=faq)

@router.get("/faqs/", response_model=List[schemas.FAQ])
def get_faqs(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    return crud.get_faqs(db, skip=skip, limit=limit)

# Routes for EventAnnouncement

@router.post("/event_announcements/", response_model=schemas.EventAnnouncement)
def create_event_announcement(event_announcement: schemas.EventAnnouncementCreate, db: Session = Depends(get_db)):
    return crud.create_event_announcement(db, event_announcement=event_announcement)

@router.get("/event_announcements/", response_model=List[schemas.EventAnnouncement])
def get_event_announcements(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    return crud.get_event_announcements(db, skip=skip, limit=limit)

# Routes for SocialLink

@router.post("/social_links/", response_model=schemas.SocialLink)
def create_social_link(social_link: schemas.SocialLinkCreate, db: Session = Depends(get_db)):
    return crud.create_social_link(db, social_link=social_link)

@router.get("/social_links/", response_model=List[schemas.SocialLink])
def get_social_links(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    return crud.get_social_links(db, skip=skip, limit=limit)

# Routes for Waitlist

@router.post("/waitlists/", response_model=schemas.Waitlist)
def create_waitlist(waitlist: schemas.WaitlistCreate, db: Session = Depends(get_db)):
    return crud.create_waitlist(db, waitlist=waitlist)

@router.get("/waitlists/", response_model=List[schemas.Waitlist])
def get_waitlists(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    return crud.get_waitlists(db, skip=skip, limit=limit)

# Routes for Merchandise

@router.post("/merchandises/", response_model=schemas.Merchandise)
def create_merchandise(merchandise: schemas.MerchandiseCreate, db: Session = Depends(get_db)):
    return crud.create_merchandise(db, merchandise=merchandise)

@router.get("/merchandises/", response_model=List[schemas.Merchandise])
def get_merchandises(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    return crud.get_merchandises(db, skip=skip, limit=limit)

# Routes for MerchandiseOrder

@router.post("/merchandise_orders/", response_model=schemas.MerchandiseOrder)
def create_merchandise_order(merchandise_order: schemas.MerchandiseOrderCreate, db: Session = Depends(get_db)):
    return crud.create_merchandise_order(db, merchandise_order=merchandise_order)

@router.get("/merchandise_orders/", response_model=List[schemas.MerchandiseOrder])
def get_merchandise_orders(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    return crud.get_merchandise_orders(db, skip=skip, limit=limit)

# Routes for EventReport

@router.post("/event_reports/", response_model=schemas.EventReport)
def create_event_report(event_report: schemas.EventReportCreate, db: Session = Depends(get_db)):
    return crud.create_event_report(db, event_report=event_report)

@router.get("/event_reports/", response_model=List[schemas.EventReport])
def get_event_reports(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    return crud.get_event_reports(db, skip=skip, limit=limit)
