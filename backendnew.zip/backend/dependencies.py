
from typing import Generator
from jose import JWTError, jwt
from fastapi import Depends, HTTPException, status
from sqlalchemy.orm import Session
from . import crud, models, schemas, security
from .database import SessionLocal

# Dependency for database session
def get_db() -> Generator:
    try:
        db = SessionLocal()
        yield db
    finally:
        db.close()

# Dependency for getting the current user from the token
def get_current_user(db: Session = Depends(get_db), token: str = Depends(oauth2_scheme)) -> models.User:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail='Could not validate credentials',
        headers={'WWW-Authenticate': 'Bearer'},
    )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        username: str = payload.get('sub')
        if username is None:
            raise credentials_exception
        token_data = schemas.TokenData(username=username)
    except JWTError:
        raise credentials_exception
    user = crud.get_user_by_username(db, username=token_data.username)
    if user is None:
        raise credentials_exception
    return user

# Dependency for getting the current active user
def get_current_active_user(current_user: models.User = Depends(get_current_user)) -> models.User:
    if current_user.disabled:
        raise HTTPException(status_code=400, detail='Inactive user')
    return current_user

# Dependencies to get specific items from the database

def get_event(db: Session, event_id: int) -> models.Event:
    event = crud.get_event(db, event_id=event_id)
    if event is None:
        raise HTTPException(status_code=404, detail='Event not found')
    return event

def get_ticket(db: Session, ticket_id: int) -> models.Ticket:
    ticket = crud.get_ticket(db, ticket_id=ticket_id)
    if ticket is None:
        raise HTTPException(status_code=404, detail='Ticket not found')
    return ticket

def get_user(db: Session, user_id: int) -> models.User:
    user = crud.get_user(db, user_id=user_id)
    if user is None:
        raise HTTPException(status_code=404, detail='User not found')
    return user

# Dependencies for role-based access control

def get_current_admin(current_user: models.User = Depends(get_current_user)) -> models.User:
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail='No access')
    return current_user

def get_current_superuser(current_user: models.User = Depends(get_current_user)) -> models.User:
    if not current_user.is_superuser:
        raise HTTPException(status_code=403, detail='No access')
    return current_user

# Dependencies to validate input data

def validate_date_range(start_date: datetime, end_date: datetime):
    if start_date >= end_date:
        raise HTTPException(status_code=400, detail='Invalid date range')
    return start_date, end_date

def validate_ticket_availability(db: Session, ticket_id: int, quantity: int):
    ticket = crud.get_ticket(db, ticket_id=ticket_id)
    if ticket is None or ticket.available_quantity < quantity:
        raise HTTPException(status_code=400, detail='Not enough tickets available')
    return ticket

# ... (Additional dependencies can be created as per application requirement)

# Admin access

def admin_access(current_user: models.User = Depends(get_current_user)) -> models.User:
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail='Admin access required')
    return current_user

# User access

def user_access(current_user: models.User = Depends(get_current_user)) -> models.User:
    if current_user.is_admin:
        raise HTTPException(status_code=403, detail='User access required')
    return current_user

# Item ownership

def user_owns_ticket(current_user: models.User = Depends(get_current_user), ticket: models.Ticket = Depends(get_ticket)) -> models.Ticket:
    if ticket.owner_id != current_user.id:
        raise HTTPException(status_code=403, detail='User does not own this ticket')
    return ticket

# Event management

def can_manage_event(current_user: models.User = Depends(get_current_user), event: models.Event = Depends(get_event)) -> models.Event:
    if event.manager_id != current_user.id:
        raise HTTPException(status_code=403, detail='User cannot manage this event')
    return event

# ... (Additional dependencies can be created as per application requirement)
