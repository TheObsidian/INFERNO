
def get_users(db: Session, skip: int = 0, limit: int = 10):
    return db.query(models.User).offset(skip).limit(limit).all()

def create_user(db: Session, user: models.UserCreate):
    db_user = models.User(**user.dict())
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def get_tickets(db: Session, skip: int = 0, limit: int = 10):
    return db.query(models.Ticket).offset(skip).limit(limit).all()

def create_ticket(db: Session, ticket: models.TicketCreate):
    db_ticket = models.Ticket(**ticket.dict())
    db.add(db_ticket)
    db.commit()
    db.refresh(db_ticket)
    return db_ticket

def create_event_schedule(db: Session, event_schedule: models.EventScheduleCreate):
    db_event_schedule = models.EventSchedule(**event_schedule.dict())
    db.add(db_event_schedule)
    db.commit()
    db.refresh(db_event_schedule)
    return db_event_schedule

def get_event_schedules(db: Session, skip: int = 0, limit: int = 10):
    return db.query(models.EventSchedule).offset(skip).limit(limit).all()

# ... (Similar CRUD operations for Feedback, EventAttendee, FAQ, EventAnnouncement, SocialLink, Waitlist, Merchandise, MerchandiseOrder, EventReport)

def create_feedback(db: Session, feedback: models.FeedbackCreate):
    db_feedback = models.Feedback(**feedback.dict())
    db.add(db_feedback)
    db.commit()
    db.refresh(db_feedback)
    return db_feedback

def get_feedbacks(db: Session, skip: int = 0, limit: int = 10):
    return db.query(models.Feedback).offset(skip).limit(limit).all()

def create_event_attendee(db: Session, event_attendee: models.EventAttendeeCreate):
    db_event_attendee = models.EventAttendee(**event_attendee.dict())
    db.add(db_event_attendee)
    db.commit()
    db.refresh(db_event_attendee)
    return db_event_attendee

def get_event_attendees(db: Session, skip: int = 0, limit: int = 10):
    return db.query(models.EventAttendee).offset(skip).limit(limit).all()

# ... (And so on for the rest of the new models)

# CRUD operations for Category

def create_category(db: Session, category: schemas.CategoryCreate):
    db_category = models.Category(**category.dict())
    db.add(db_category)
    db.commit()
    db.refresh(db_category)
    return db_category

def get_categories(db: Session, skip: int = 0, limit: int = 10):
    return db.query(models.Category).offset(skip).limit(limit).all()

def get_category(db: Session, category_id: int):
    return db.query(models.Category).filter(models.Category.id == category_id).first()

def update_category(db: Session, db_category: models.Category, category: schemas.CategoryCreate):
    for key, value in category.dict().items():
        setattr(db_category, key, value)
    db.commit()
    db.refresh(db_category)
    return db_category

def delete_category(db: Session, db_category: models.Category):
    db.delete(db_category)
    db.commit()
    return db_category
