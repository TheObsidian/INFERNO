
from typing import List, Optional
from pydantic import BaseModel

# User
class UserCreate(BaseModel):
    username: str
    email: str

class User(UserCreate):
    id: int
    
    class Config:
        orm_mode = True

# Ticket
class TicketCreate(BaseModel):
    title: str
    description: str

class Ticket(TicketCreate):
    id: int
    
    class Config:
        orm_mode = True

# EventSchedule
class EventScheduleCreate(BaseModel):
    event_name: str
    start_time: str  # Using str for simplicity; consider using datetime for real use
    end_time: str

class EventSchedule(EventScheduleCreate):
    id: int
    
    class Config:
        orm_mode = True

# ... (And so on for Feedback, EventAttendee, FAQ, EventAnnouncement, SocialLink, Waitlist, Merchandise, MerchandiseOrder, EventReport)

# Feedback
class FeedbackCreate(BaseModel):
    event_id: int
    user_id: int
    comment: str
    rating: int

class Feedback(FeedbackCreate):
    id: int
    
    class Config:
        orm_mode = True

# EventAttendee
class EventAttendeeCreate(BaseModel):
    event_id: int
    user_id: int

class EventAttendee(EventAttendeeCreate):
    id: int
    
    class Config:
        orm_mode = True

# ... (And so on for FAQ, EventAnnouncement, SocialLink, Waitlist, Merchandise, MerchandiseOrder, EventReport)

# FAQ
class FAQCreate(BaseModel):
    event_id: int
    question: str
    answer: str

class FAQ(FAQCreate):
    id: int
    
    class Config:
        orm_mode = True

# EventAnnouncement
class EventAnnouncementCreate(BaseModel):
    event_id: int
    announcement: str

class EventAnnouncement(EventAnnouncementCreate):
    id: int
    
    class Config:
        orm_mode = True

# SocialLink
class SocialLinkCreate(BaseModel):
    event_id: int
    platform: str
    link: str

class SocialLink(SocialLinkCreate):
    id: int
    
    class Config:
        orm_mode = True

# Waitlist
class WaitlistCreate(BaseModel):
    event_id: int
    user_id: int

class Waitlist(WaitlistCreate):
    id: int
    
    class Config:
        orm_mode = True

# Merchandise
class MerchandiseCreate(BaseModel):
    event_id: int
    name: str
    description: str
    price: float

class Merchandise(MerchandiseCreate):
    id: int
    
    class Config:
        orm_mode = True

# MerchandiseOrder
class MerchandiseOrderCreate(BaseModel):
    merchandise_id: int
    user_id: int
    quantity: int

class MerchandiseOrder(MerchandiseOrderCreate):
    id: int
    
    class Config:
        orm_mode = True

# EventReport
class EventReportCreate(BaseModel):
    event_id: int
    report: str

class EventReport(EventReportCreate):
    id: int
    
    class Config:
        orm_mode = True

# Category Schemas
class CategoryCreate(BaseModel):
    name: str

class Category(CategoryCreate):
    id: int
    
    class Config:
        orm_mode = True
