
from fastapi import APIRouter

router_v1 = APIRouter()
router_v2 = APIRouter()

# Define API routes for different versions here
