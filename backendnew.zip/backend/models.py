
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Float, Boolean
from sqlalchemy.ext.declarative import declarative_base
import datetime

Base = declarative_base()

# ... (Previous models + New models here)
# Note: In a real-world scenario, each model might have additional configurations and relationships defined.

class EventImage(Base):
    __tablename__ = 'event_images'
    id = Column(Integer, primary_key=True, index=True)
    event_id = Column(Integer, ForeignKey('events.id'), nullable=False)
    image_url = Column(String(255), nullable=False)
    is_primary = Column(Boolean, default=False)

class UserRole(Base):
    __tablename__ = 'user_roles'
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), unique=True, nullable=False)
    description = Column(String(255), nullable=True)

class EventTicketType(Base):
    __tablename__ = 'event_ticket_types'
    id = Column(Integer, primary_key=True, index=True)
    event_id = Column(Integer, ForeignKey('events.id'), nullable=False)
    name = Column(String(50), nullable=False)
    price = Column(Float, nullable=False)
    quantity_available = Column(Integer, nullable=False)

class UserEventBookmark(Base):
    __tablename__ = 'user_event_bookmarks'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    event_id = Column(Integer, ForeignKey('events.id'), nullable=False)
    bookmarked_at = Column(DateTime, default=datetime.datetime.utcnow)

class Messaging(Base):
    __tablename__ = 'messagings'
    id = Column(Integer, primary_key=True, index=True)
    sender_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    receiver_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    message = Column(String(500), nullable=False)
    sent_at = Column(DateTime, default=datetime.datetime.utcnow)

class DiscussionForum(Base):
    __tablename__ = 'discussion_forums'
    id = Column(Integer, primary_key=True, index=True)
    event_id = Column(Integer, ForeignKey('events.id'), nullable=False)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    message = Column(String(500), nullable=False)
    posted_at = Column(DateTime, default=datetime.datetime.utcnow)

class Vendor(Base):
    __tablename__ = 'vendors'
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    service_type = Column(String(100), nullable=False)
    contact_info = Column(String(255), nullable=True)

class EventVendor(Base):
    __tablename__ = 'event_vendors'
    id = Column(Integer, primary_key=True, index=True)
    event_id = Column(Integer, ForeignKey('events.id'), nullable=False)
    vendor_id = Column(Integer, ForeignKey('vendors.id'), nullable=False)

class DiscountCode(Base):
    __tablename__ = 'discount_codes'
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(50), unique=True, nullable=False)
    discount_amount = Column(Float, nullable=False)
    valid_from = Column(DateTime, nullable=False)
    valid_until = Column(DateTime, nullable=False)

class UserPurchaseHistory(Base):
    __tablename__ = 'user_purchase_history'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    ticket_id = Column(Integer, ForeignKey('tickets.id'), nullable=False)
    purchased_at = Column(DateTime, default=datetime.datetime.utcnow)
    payment_id = Column(Integer, ForeignKey('payments.id'), nullable=False)

class EventSchedule(Base):
    __tablename__ = 'event_schedules'
    id = Column(Integer, primary_key=True, index=True)
    event_id = Column(Integer, ForeignKey('events.id'), nullable=False)
    start_time = Column(DateTime, nullable=False)
    end_time = Column(DateTime, nullable=False)
    description = Column(String(255), nullable=True)

class Feedback(Base):
    __tablename__ = 'feedbacks'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    event_id = Column(Integer, ForeignKey('events.id'), nullable=False)
    feedback_text = Column(String(500), nullable=False)
    rating = Column(Integer, nullable=False)
    submitted_at = Column(DateTime, default=datetime.datetime.utcnow)

class EventAttendee(Base):
    __tablename__ = 'event_attendees'
    id = Column(Integer, primary_key=True, index=True)
    event_id = Column(Integer, ForeignKey('events.id'), nullable=False)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    ticket_id = Column(Integer, ForeignKey('tickets.id'), nullable=False)
    attended = Column(Boolean, default=False)

class FAQ(Base):
    __tablename__ = 'faqs'
    id = Column(Integer, primary_key=True, index=True)
    event_id = Column(Integer, ForeignKey('events.id'), nullable=False)
    question = Column(String(255), nullable=False)
    answer = Column(String(500), nullable=False)

class EventAnnouncement(Base):
    __tablename__ = 'event_announcements'
    id = Column(Integer, primary_key=True, index=True)
    event_id = Column(Integer, ForeignKey('events.id'), nullable=False)
    title = Column(String(100), nullable=False)
    description = Column(String(500), nullable=False)
    announced_at = Column(DateTime, default=datetime.datetime.utcnow)

class SocialLink(Base):
    __tablename__ = 'social_links'
    id = Column(Integer, primary_key=True, index=True)
    entity_id = Column(Integer, nullable=False)  # Can be event_id or artist_id
    entity_type = Column(String(50), nullable=False)  # 'event' or 'artist'
    platform_name = Column(String(50), nullable=False)  # e.g., 'Facebook', 'Instagram'
    link_url = Column(String(255), nullable=False)

class Waitlist(Base):
    __tablename__ = 'waitlists'
    id = Column(Integer, primary_key=True, index=True)
    event_id = Column(Integer, ForeignKey('events.id'), nullable=False)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    added_at = Column(DateTime, default=datetime.datetime.utcnow)

class Merchandise(Base):
    __tablename__ = 'merchandises'
    id = Column(Integer, primary_key=True, index=True)
    event_id = Column(Integer, ForeignKey('events.id'), nullable=False)
    name = Column(String(100), nullable=False)
    price = Column(Float, nullable=False)
    stock_quantity = Column(Integer, nullable=False)

class MerchandiseOrder(Base):
    __tablename__ = 'merchandise_orders'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    merchandise_id = Column(Integer, ForeignKey('merchandises.id'), nullable=False)
    order_date = Column(DateTime, default=datetime.datetime.utcnow)
    quantity = Column(Integer, nullable=False)
    status = Column(String(50), nullable=False)  # e.g., 'processed', 'shipped', 'delivered'

class EventReport(Base):
    __tablename__ = 'event_reports'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    event_id = Column(Integer, ForeignKey('events.id'), nullable=False)
    report_text = Column(String(500), nullable=False)
    submitted_at = Column(DateTime, default=datetime.datetime.utcnow)

# Category Model
class Category(Base):
    __tablename__ = 'categories'

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
