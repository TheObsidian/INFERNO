
from fastapi.testclient import TestClient

# Example test
def test_example():
    assert 1 == 1
