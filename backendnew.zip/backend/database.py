
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# SQLALCHEMY_DATABASE_URL = "sqlite:///./test.db"  # SQLite
# SQLALCHEMY_DATABASE_URL = "postgresql://user:password@postgresserver/db"  # PostgreSQL

# Option 1: SQLite for development
SQLALCHEMY_DATABASE_URL = "sqlite:///./test.db"

# Option 2: PostgreSQL for production (use actual credentials and URL)
# SQLALCHEMY_DATABASE_URL = "postgresql://user:password@postgresserver/db"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    # Only for SQLite: connect_args={"check_same_thread": False}  # Only use with SQLite
)

# Use scoped_session for thread-safety in concurrent scenarios (e.g., when using async)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base model to be used by other models
Base = declarative_base()
