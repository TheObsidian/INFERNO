
from typing import List, Generic, TypeVar, Optional
from pydantic import BaseModel, create_model
from pydantic.generics import GenericModel

DataT = TypeVar('DataT')

class Pagination(BaseModel):
    total: int
    skip: Optional[int] = None
    limit: Optional[int] = None

class PaginatedResponse(GenericModel, Generic[DataT]):
    items: List[DataT]
    pagination: Pagination

# Now create specific paginated response models for events, tickets, and users using the generic PaginatedResponse
from . import schemas

PaginatedEventResponse = create_model('PaginatedEventResponse', __base__=PaginatedResponse[schemas.Event])
PaginatedTicketResponse = create_model('PaginatedTicketResponse', __base__=PaginatedResponse[schemas.Ticket])
PaginatedUserResponse = create_model('PaginatedUserResponse', __base__=PaginatedResponse[schemas.User])
