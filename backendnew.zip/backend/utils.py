
# Utility functions can be defined here
